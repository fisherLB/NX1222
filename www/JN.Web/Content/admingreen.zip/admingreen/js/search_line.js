$(function(){


$('span.style3').parent().each(function(){
 $(this).click(function(){
 
 

});

});

 $('#search_line').hover(function(){
   alert();
 });














  



});